const Property = require("../../models/Property");


const updateProperty = async (req, res) => {
  // Controller for editing the logged-in user details
  if (req.method === "PUT") {
    let success = false;
    try {
      const { propertyId } = req.body;
        const property = await Property.findByIdAndUpdate(
        propertyId,
        { ...req.body },
        { new: true }
      );
      success = true;
      return res.status(200).json({ success, property });
    } catch (error) {
      success = false;
      return res.status(500).json({ success, error: error.message });
    }
  } else {
    return res.status(405).json({ error: "Method Not allowed!" });
  }
};

module.exports = updateProperty;
