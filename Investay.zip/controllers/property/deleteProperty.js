const Property = require("../../models/Property");

const deleteProperty = async (req, res) => {
    // Controller for editing the logged-in user details
    if (req.method === "DELETE") {
        let success = false;
        try {
            const property = await Property.findByIdAndDelete(req.query.id);
            success = true;
            return res.status(200).json({ success, property });
        } catch (error) {
            success = false;
            return res.status(500).json({ success, error: error.message });
        }
    } else {
        return res.status(405).json({ error: "Method Not allowed!" });
    }
};

module.exports = deleteProperty;
