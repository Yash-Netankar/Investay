import React from 'react'

const ProfileSidebar = () => {
  return (
    <div>ProfileSidebar</div>
  )
}

export default ProfileSidebar