import { PlusIcon, UserCircleIcon } from '@heroicons/react/20/solid'
import Image from 'next/image'
import Link from 'next/link'
import { useRouter } from 'next/router'
import React, { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { updateProperty } from '../../action-creators/properties/updateProperty'
import { DeleteIcon } from '../SVGComponents/Admin/DeleteIcon'
import { UserCircle } from '../SVGComponents/Admin/UserCircle'
import { DownArrow } from '../SVGComponents/DownArrow'
import { deleteProperty } from '../../action-creators/properties/deleteProperty'

const DashboardListings = ({ allProperties }: any) => {
    const router = useRouter()
    const [availedServiceOptionsShow, setAvailedServiceOptionsShow] = useState(false)
    const [propertyStatusOptionsShow, setPropertyStatusOptionsShow] = useState(false)
    const [approvalStatusOptionsShow, setApprovalStatusOptionsShow] = useState(false)

    const [properties, setProperties] = useState([]) as any

    const getAllProperty = () => {
        setProperties(allProperties)
    }

    useEffect(() => {
        if (allProperties) {
            console.log("run")
            getAllProperty()
        }
    }, [])

    const filter = (filterBy: String) => {
        setProperties(allProperties)

        setProperties(
            allProperties?.filter((property: any) => {
                if (filterBy === "resale" || filterBy === "rental") {
                    return filterBy === property?.category
                }
                if (filterBy == "published" || filterBy == "rejected" || filterBy == "pending") {
                    return filterBy === property?.status
                }
                if (filterBy === "available" || filterBy === "sold" || filterBy === "rented") {
                    return filterBy === property?.saleStatus
                }
            })
        )
    }

    // fix 7 : property status highlited
    // fix 8 : property deleting in same function
    const propertyActivateStatusChange = async (propertyActivateStatus: string, propertyId: any) => {
        try {
            if (propertyActivateStatus == "deleted") {
                const response = await deleteProperty(propertyId);
                if (response.success) {
                    allProperties = properties.filter((property: { _id: any }) => property._id != propertyId)
                    setProperties(allProperties)

                    toast.success("Property Deleted Successfully", {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "light",
                    });
                }
            }

            else {
                const response = await updateProperty({ propertyActivateStatus, propertyId });
                if (response.success) {
                    const id = properties.findIndex((property: { _id: any }) => property._id == propertyId)
                    setProperties((prev:any) => {
                        if(prev[id]?._id == propertyId){
                            prev[id]["propertyActivateStatus"] = propertyActivateStatus
                        }
                        return [...prev]
                    })

                    toast.success("Property  Status Updated Successfully", {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "light",
                    });
                }
            }
        }
        catch (error: any) {
            toast.error(error.response.data.error, {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light",
            });

        }


    }


    return (
        <>
            <div className='flex justify-end'>
                <div className='flex  md:flex-row flex-col z-10 absolute'>
                    <div className=''>
                        <span className='mx-4 shadow-md p-3 flex cursor-pointer ' onClick={() => {
                            setAvailedServiceOptionsShow(!availedServiceOptionsShow)
                            setPropertyStatusOptionsShow(false)
                            setApprovalStatusOptionsShow(false)
                            getAllProperty()
                        }} >
                            <span > Availed Services</span>
                            <span className='mt-2 mx-2 '>
                                <DownArrow className='text-gray-300' />
                            </span>
                        </span>
                        {
                            availedServiceOptionsShow &&
                            <span className='mx-4 my-2 shadow-md bg-gray-100 flex flex-col text-center cursor-pointer ' >
                                <span onClick={() => { filter("rental") }} className=' p-2 border hover:bg-gray-300'> Rental</span>
                                <span onClick={() => { filter("resale") }} className='p-2 border hover:bg-gray-300'> Resale</span>
                            </span>
                        }
                    </div>
                    <div>
                        <span className='mx-4 shadow-md p-3 flex cursor-pointer' onClick={() => {
                            setPropertyStatusOptionsShow(!propertyStatusOptionsShow)
                            setAvailedServiceOptionsShow(false)
                            setApprovalStatusOptionsShow(false)
                            getAllProperty()
                        }}>
                            <span >   Property Status</span>
                            <span className='mt-2 mx-2 '>
                                <DownArrow className='text-gray-300' />
                            </span>
                        </span>
                        {
                            propertyStatusOptionsShow &&
                            <span className='mx-4 my-2 shadow-md bg-gray-100 flex flex-col text-center cursor-pointer ' >
                                <span onClick={() => { filter("available") }} className=' p-2 border hover:bg-gray-300'> Available</span>
                                <span onClick={() => { filter("sold") }} className='p-2 border hover:bg-gray-300'> Sold Out</span>
                                <span onClick={() => { filter("rented") }} className='p-2 border hover:bg-gray-300'> Rented Out</span>
                            </span>
                        }
                    </div>
                    <div >
                        <span className='mx-4  shadow-md p-3 flex cursor-pointer' onClick={() => {
                            setApprovalStatusOptionsShow(!approvalStatusOptionsShow)
                            setAvailedServiceOptionsShow(false)
                            setPropertyStatusOptionsShow(false)
                            getAllProperty()
                        }}>
                            <span> Approval Status</span>
                            <span className='mt-2 mx-2 '>
                                <DownArrow className='text-gray-300' />
                            </span>
                        </span>
                        {
                            approvalStatusOptionsShow &&
                            <span className='mx-4 my-2 shadow-md bg-gray-100 flex flex-col text-center cursor-pointer ' >
                                <span onClick={() => { filter("published") }} className=' p-2 border hover:bg-gray-300'> Approved</span>
                                <span onClick={() => { filter("pending") }} className='p-2 border hover:bg-gray-300'> Pending</span>
                                <span onClick={() => { filter("rejected") }} className='p-2 border hover:bg-gray-300'> Rejected</span>
                            </span>
                        }
                    </div>

                </div>
            </div>

            <div className="grid md:mt-20 mt-32 grid-cols-12" onClick={() => {
                setAvailedServiceOptionsShow(false)
                setPropertyStatusOptionsShow(false)
                setApprovalStatusOptionsShow(false)

            }}>
                <div className="xl:col-span-4 md:col-span-6  col-span-12 h-full p-6 mx-3 shadow-lg flex flex-col rounded-lg overflow-hidden">
                    <div className="h-48 xxs:h-[15.2rem] w-full flex justify-center ">
                        <div
                            onClick={() => {
                                router.push("/admin/add-property");
                            }}
                            className=" my-10 flex justify-center cursor-pointer items-center flex-col"
                        >
                            <PlusIcon className="w-8 h-8  " />
                            <p className="text-center">Add New Property</p>
                        </div>
                    </div>


                </div>
                {properties && properties?.map((property: any, index: any) => {
                    return (
                        <div key={index} className="xl:col-span-4 md:col-span-6  col-span-12 h-full p-6 mx-3 shadow-lg flex flex-col rounded-lg overflow-hidden">
                            <div className="h-48 xxs:h-[15.2rem] w-full relative overflow-hidden">
                                {

                                    property?.status === "published" &&
                                    <span className="bg-greenBg text-white text-base absolute rounded-md px-6 py-2 flex justify-center items-center">
                                        Approved
                                    </span>
                                }
                                {
                                    property?.status === "pending" &&
                                    <span className="bg-primaryColor text-white text-base  absolute w-56 -mr-12 right-0 rotate-[30deg] mt-6 px-10  py-2 flex justify-center items-center">
                                        Pending
                                    </span>
                                }
                                {
                                    property?.status === "rejected" &&
                                    <span className="bg-danger text-white text-sm absolute  w-56 -mr-12 right-0 rotate-[30deg] mt-6 px-10  py-2 flex justify-center items-center">
                                        Rejected
                                    </span>
                                }
                                {/*  fix 4 : highlight tab */}
                                <div className='flex justify-center '>
                                    <div className="  text-sm absolute  w-full inset-x-0 bottom-0  px-10  flex justify-center items-center">
                                        <span onClick={() => propertyActivateStatusChange("deactivated", property?._id)} className={`p-2 bg-white rounded-l-lg cursor-pointer flex flex-col ${property?.propertyActivateStatus == "deactivated" && "bg-gray-400"} `}>
                                            <span className='flex justify-center'>
                                                <UserCircle className='h-6 w-6  text-[#F4B715] ' />
                                            </span>
                                            <span className='text-xs'>De-activate</span>
                                        </span>
                                        <span onClick={() => propertyActivateStatusChange("activated", property?._id)} className={`p-2 bg-white  cursor-pointer  flex flex-col ${property?.propertyActivateStatus == "activated" && "bg-gray-400"} `}>
                                            <span className='flex justify-center'>
                                                <UserCircle className='h-6 w-6  text-[#F4B715]' />
                                            </span>
                                            <span className='text-xs'>Activate</span>
                                        </span>
                                        <span onClick={() => propertyActivateStatusChange("deleted", property?._id)} className={`p-2 bg-white rounded-r-lg cursor-pointer  flex flex-col ${property?.propertyActivateStatus == "deleted" && "bg-gray-400"} `}>
                                            <span className='flex justify-center'>

                                                <DeleteIcon className='h-6 w-6  text-[#F4B715]' />
                                            </span>
                                            <span className='text-xs'>Delete</span>
                                        </span>
                                    </div>

                                </div>

                                {/* fix 5 : image issue fixed */}
                                <Link href={`/admin/property-overview/${property?._id}`}>
                                    <div className="w-full h-full flex justify-center cursor-pointer items-center rounded-t-lg bg-[#DCDCDC]">
                                        <img src={"/uploads/" + property.gallery[0]?.filename} alt="Property Image" className="h-full w-full object-fit" />

                                    </div>
                                </Link>

                            </div>

                            <div className=" mt-1 xxs:mt-4 ">
                                <div className="px-2 lg1:px-4 mt-2 flex items-start justify-between">
                                    <div className="flex gap-x-4">
                                        <div className="space-y-2">
                                            <div className="text-xl font-bold">{property?.projectName}</div>
                                            <span className="text-sm "> {property?.addressLine1}  </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )
                })
                }
                {
                    properties?.length === 0 &&
                    <div className='flex justify-center h-screen col-span-12' onClick={() => {
                        setAvailedServiceOptionsShow(false)
                        setPropertyStatusOptionsShow(false)
                        setApprovalStatusOptionsShow(false)

                    }}>
                        <div> No properties Available</div>
                    </div>
                }
            </div>
        </>
    )
}

export default DashboardListings