import deleteProperty from "../../../controllers/property/deleteProperty";
import fetchUser from "../../../middlewares/fetchUser";
import grantAccess from "../../../middlewares/grantAccess";

// export const config = {
//     api: {
//       bodyParser: false,
//     },
//   };
  
// API route for editing the logged-in user details
const handler = deleteProperty;

export default fetchUser(grantAccess("updateOwn", "profile", handler));
