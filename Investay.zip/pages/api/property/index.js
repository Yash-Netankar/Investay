import getProperties from "../../../controllers/property/index";

const handler = getProperties;

export default handler;
