import allProperties from "../../../controllers/property/allProperties";

const handler = allProperties;

export default handler;