import getToken from "../../../controllers/token";

const handler = getToken;

export default handler;
