const verifyOtp = require("../../../controllers/auth/verifyOtp");

const handler = verifyOtp;

export default handler;