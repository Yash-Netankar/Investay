import register from "../../../controllers/auth/register";

// API route for registering new user
const handler = register;

export default handler;
