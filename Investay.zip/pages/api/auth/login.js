import login from "../../../controllers/auth/login";

// API route for logging in existing user
const handler = login;

export default handler;
