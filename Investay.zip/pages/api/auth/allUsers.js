
const allUsers = require("../../../controllers/auth/allUsers");

const handler = allUsers;

export default handler;