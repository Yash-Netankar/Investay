import register from "../../../../controllers/auth/admin/register";

// API route for registering new admin
const handler = register;

export default handler;