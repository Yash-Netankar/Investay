import login from "../../../../controllers/auth/admin/login";

// API route for logging in existing user
const handler = login;

export default handler;
