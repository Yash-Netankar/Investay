
const allEnquiries = require("../../../controllers/enquiry");

const handler = allEnquiries;

export default handler;
