const getReviews = require("../../../controllers/review");

const handler = getReviews;

export default handler;
