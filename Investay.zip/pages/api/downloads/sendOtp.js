const sendOtp = require("../../../controllers/downloads/sendOtp");

const handler = sendOtp;

export default handler;