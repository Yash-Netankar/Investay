import downloadFile from "../../../controllers/downloads";

const handler = downloadFile;

export default handler;