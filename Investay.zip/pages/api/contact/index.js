import contact from "../../../controllers/contact";

const handler = contact

export default handler;