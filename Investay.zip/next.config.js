/** @type {import('next').NextConfig} */
module.exports = {
  async headers() {
    return [
      {
        // matching all API routes
        source: "/api/:path*",
        headers: [
          { key: "Access-Control-Allow-Credentials", value: "true" },
          { key: "Access-Control-Allow-Origin", value: "https://investay-staging-v2.vercel.app" },
          { key: "Access-Control-Allow-Methods", value: "GET,OPTIONS,PATCH,DELETE,POST,PUT" },
          { key: "Access-Control-Allow-Headers", value: "X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version" },
        ]
      }
    ]
  },
  reactStrictMode: false,
  images: {
    loader: "akamai",
    path: "/",
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  trailingSlash: false,
  compiler: {
    styledComponents: true,
  },
  env: {
    NEXT_PUBLIC_APP_NAME: "Investay",
    NEXT_PUBLIC_GOOGLE_MAPS_API_KEY: "AIzaSyAQlaZZ1hxQyLCEasQ0oVavoheldLO3SDw",
    NEXT_PUBLIC_HOST_URL: "http://localhost:3000",
    JWT_SECRET: "MY_INVESTAY_SECRET_2625",
    MONGO_URI: "mongodb+srv://Dev_Investay:aTy1wuVvlosk9yrZ@cluster0.uuddpu1.mongodb.net/investay?retryWrites=true&w=majority",
    NEXT: "investay2625@gmail.com",
    NEXT_MAILER_PASSWORD1: "osjhmvutwrshspud",
    NEXT_MAILER_PASSWORD: "tszddiankvrgrbmi",
    SEND_GRID_EMAIL: "investay2625@gmail.com",
    SEND_GRID_KEY: "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",
    TWILIO_ACCOUNT_SID: "AC407359e6f4df677f0c77c9dcf228d506",
    TWILIO_VERIFY_SID: "VA4a801b96c5ce29d65f7a4377bb1cc47c",
    TWILIO_AUTH_TOKEN: "dc8c5db9620af4f4094ebcea6cf93c11",
    TWILIO_NUMBER: "+18787787168",
    TWILIO_MESSAGING_SERVICE_SID: "MG9160938c76a4336646ac1dca6b980deb",
    NEXT_PUBLIC_INVESTAY_LINK_LOCAL: "http://localhost:3000",
    NEXT_PUBLIC_INVESTAY_LINK_PROD: "https://investay-v2.vercel.app",
    NEXT_PUBLIC_NODE_ENV: "production",
  }
};
