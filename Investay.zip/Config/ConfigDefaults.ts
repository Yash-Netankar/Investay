let slugName = "Investay";

const ConfigDefaults = {
  name: {
    slugName: slugName,
  },
};

export default ConfigDefaults;
