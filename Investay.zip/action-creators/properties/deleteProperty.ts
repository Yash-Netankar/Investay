import axios from "axios";
export const deleteProperty = async (id: any) => {
  const url =
    process.env.NEXT_PUBLIC_NODE_ENV === "development"
      ? process.env.NEXT_PUBLIC_INVESTAY_LINK_LOCAL
      : process.env.NEXT_PUBLIC_INVESTAY_LINK_PROD;

  const { data } = await axios.delete(`${url}/api/property/deleteProperty/?id=${id}`);
  return data;
};
